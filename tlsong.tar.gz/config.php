<?php
// --- 資料庫設定 ---
define('DB_HOST', 'localhost');
// !!! 請確認並填寫正確的資料庫使用者名稱 !!!
define('DB_USER', 'sql_34_150_57_14'); 
define('DB_PASS', '61aa2f4b731758');
define('DB_NAME', 'sql_34_150_57_14');

// --- 應用程式設定 ---
define('MAX_RECOMMENDATIONS', 10);