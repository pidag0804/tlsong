<?php
// (檔案頂部的 session, require, 路由等邏輯保持不變)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = session_id();
}

require_once 'config.php';
require_once 'functions.php';

$page = $_GET['page'] ?? 'form';

$allowed_pages = ['form', 'preview', 'export'];
if (!in_array($page, $allowed_pages)) {
    $page = 'form';
}

$page_title = [
    'form' => '歌曲推薦系統',
    'preview' => '我的推薦清單',
    'export' => '所有玩家推薦腳本'
];

?>
<!DOCTYPE html>
<html lang="zh-Hant">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title[$page] ?> - Dark-Tech</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700&family=Noto+Sans+TC:wght@400;700&family=Space+Grotesk:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="main-container">
        <?php include "views/{$page}.php"; ?>
    </div>
    
    <script src="assets/main.js"></script>
    
    <?php if ($page === 'preview'): ?>
    <script src="https://www.youtube.com/iframe_api"></script>
    <?php endif; ?>

</body>
</html>